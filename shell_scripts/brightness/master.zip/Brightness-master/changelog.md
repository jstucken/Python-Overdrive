# Change Log

2017-05-24: Added support for arbitary number of displays. Removed reverse control since it becomes unnecessary.